﻿using UnityEngine;
using System.Collections;
using UnityEngine.SceneManagement;

public class ChangeScene_Credit : MonoBehaviour
{

    // Use this for initialization
    void Start()
    {

    }

    public void Pressbutton()
    {
        SceneManager.LoadScene("Credit");
    }

    // Update is called once per frame
    void Update()
    {

    }
}
